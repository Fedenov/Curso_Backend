const productController = require("./productController");
const viewController = require("./viewController");
module.exports = { productController, viewController };
